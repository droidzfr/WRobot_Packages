﻿using System;
using System.Threading;
using System.Collections.Generic;
using wManager.Wow.Bot.Tasks;
using wManager.Wow.ObjectManager;
using robotManager.Helpful;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using XmlSerializer = System.Xml.Serialization.XmlSerializer;
using System.Windows.Forms;
using wManager.Wow.Enums;
using wManager.Wow.Helpers;
using System.Net;
using System.Collections.Specialized;
using System.Text;

namespace InstanceKillerSingle
{
    public static class Utils
    {
        public static void OpenTheDoor()
        {
            List<WoWGameObject> woWGameObjects = ObjectManager.GetObjectWoWGameObject();
            for (int j = 0; j < woWGameObjects.Count; j++)
            {
                if (GlobalVar.InstanceKillerSingleSettings.intecractObjectEntry.Exists(t => t == woWGameObjects[j].Entry) && ObjectManager.Me.Position.DistanceTo2D(woWGameObjects[j].Position) <= 10f)
                {
                    GoToTask.ToPositionAndIntecractWithGameObject(woWGameObjects[j].Position, woWGameObjects[j].Entry);
                    Thread.Sleep(1000);
                }
            }
            if (Usefuls.ContinentId == 33)
            {
                List<WoWUnit> woWUnits = ObjectManager.GetObjectWoWUnit();
                for (int i = 0; i < woWUnits.Count; i++)
                {
                    if (GlobalVar.InstanceKillerSingleSettings.intecractObjectEntry.Exists(t => t == woWUnits[i].Entry) && ObjectManager.Me.Position.DistanceTo2D(woWUnits[i].Position) <= 10f)
                    {
                        GoToTask.ToPositionAndIntecractWithNpc(woWUnits[i].Position, woWUnits[i].Entry);
                        Thread.Sleep(1000);
                        Quest.SelectGossipOption(1);
                    }
                }
            }
        }
        public static Int64 GetTimeStamp()
        {
            TimeSpan ts = DateTime.Now - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return Convert.ToInt64(ts.TotalSeconds);
        }
        public static bool ConfigSettingsForm()
        {
            InstanceKillerSettingsForm instanceKillerSettingsForm = new InstanceKillerSettingsForm();
            if (System.IO.File.Exists(GlobalVar.configFilePath))
            {
                try
                {
                    SettingsFormVar settingsFormVar;
                    XmlSerializer xs = new XmlSerializer(typeof(SettingsFormVar));
                    using (FileStream fs = new FileStream(GlobalVar.configFilePath, FileMode.Open))
                    {
                        settingsFormVar = xs.Deserialize(fs) as SettingsFormVar;
                    }
                    int license_remainder = CheckLicense(settingsFormVar);
                    if (license_remainder > 0)
                    {
                        if (settingsFormVar != null)
                        {
                            //血色
                            if (settingsFormVar.choseDungeon == "Scarlet Monastery - Church")
                            {
                                GlobalVar.InstanceKillerSingleSettings = GlobalVar.instanceKillerSingleSettingsClass.InstanceKillerSingleSettingXS;
                                AutoClosingMessageBox.Show(string.Format("Uses Remaind {0} ----------> Remove {1} if you want to reset", license_remainder,GlobalVar.configFilePath), "", 5000);
                                return true;
                            }
                            //监狱
                            if (settingsFormVar.choseDungeon == "The Stockade - Alliance")
                            {
                                GlobalVar.InstanceKillerSingleSettings = GlobalVar.instanceKillerSingleSettingsClass.InstanceKillerSingleSettingBFCJY;
                                AutoClosingMessageBox.Show(string.Format("Uses Remaind {0} ----------> Remove {1} if you want to reset", license_remainder, GlobalVar.configFilePath), "", 5000);
                                return true;
                            }
                            //怒焰裂谷
                            if (settingsFormVar.choseDungeon == "Ragefire Chasm - Horde")
                            {
                                GlobalVar.InstanceKillerSingleSettings = GlobalVar.instanceKillerSingleSettingsClass.InstanceKillerSingleSettingNYLG;
                                AutoClosingMessageBox.Show(string.Format("Uses Remaind {0} ----------> Remove {1} if you want to reset", license_remainder, GlobalVar.configFilePath), "", 5000);
                                return true;
                            }
                            //死亡矿井
                            if (settingsFormVar.choseDungeon == "The Deadmines - Alliance")
                            {
                                GlobalVar.InstanceKillerSingleSettings = GlobalVar.instanceKillerSingleSettingsClass.InstanceKillerSingleSettingSK;
                                AutoClosingMessageBox.Show(string.Format("Uses Remaind {0} ----------> Remove {1} if you want to reset", license_remainder, GlobalVar.configFilePath), "", 5000);
                                return true;
                            }
                            //影牙城堡
                            if (settingsFormVar.choseDungeon == "Shadowfang Keep - Horde")
                            {
                                GlobalVar.InstanceKillerSingleSettings = GlobalVar.instanceKillerSingleSettingsClass.InstanceKillerSingleSettingYYCB;
                                AutoClosingMessageBox.Show(string.Format("Uses Remaind {0} ----------> Remove {1} if you want to reset", license_remainder, GlobalVar.configFilePath), "", 5000);
                                return true;
                            }
                            //祖尔法拉克
                            if (settingsFormVar.choseDungeon == "Zul'Farrak")
                            {
                                GlobalVar.InstanceKillerSingleSettings = GlobalVar.instanceKillerSingleSettingsClass.InstanceKillerSingleSettingZUL;
                                AutoClosingMessageBox.Show(string.Format("Uses Remaind {0} ----------> Remove {1} if you want to reset", license_remainder, GlobalVar.configFilePath), "", 5000);
                                return true;
                            }
                            //通灵学院
                            if (settingsFormVar.choseDungeon == "Scholomance")
                            {
                                GlobalVar.InstanceKillerSingleSettings = GlobalVar.instanceKillerSingleSettingsClass.InstanceKillerSingleSettingTL;
                                AutoClosingMessageBox.Show(string.Format("Uses Remaind {0} ----------> Remove {1} if you want to reset", license_remainder, GlobalVar.configFilePath), "", 5000);
                                return true;
                            }
                            //斯坦索姆
                            if (settingsFormVar.choseDungeon == "Stratholme")
                            {
                                GlobalVar.InstanceKillerSingleSettings = GlobalVar.instanceKillerSingleSettingsClass.InstanceKillerSingleSettingSTSM;
                                AutoClosingMessageBox.Show(string.Format("Uses Remaind {0} ----------> Remove {1} if you want to reset", license_remainder, GlobalVar.configFilePath), "", 5000);
                                return true;
                            }
                            //黑石深渊
                            if (settingsFormVar.choseDungeon == "Blackrock Depths")
                            {
                                GlobalVar.InstanceKillerSingleSettings = GlobalVar.instanceKillerSingleSettingsClass.InstanceKillerSingleSettingHSSY;
                                AutoClosingMessageBox.Show(string.Format("Uses Remaind {0} ----------> Remove {1} if you want to reset", license_remainder, GlobalVar.configFilePath), "", 5000);
                                return true;
                            }
                        }
                    }

                }
                catch (Exception ex)
                {
                    Logging.Write(ex.ToString());
                }
            }
            instanceKillerSettingsForm.ShowDialog();
            MessageBox.Show("Settings Updated. Please Restart Products","", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return false;
        }

        public static int CheckLicense(SettingsFormVar settingsFormVar)
        {
            if (settingsFormVar.licenseKey != "")
            {
                return SendPostRequest(settingsFormVar.licenseVersion, settingsFormVar.licenseKey);
            }
            return -1;
        }

        public static int SendPostRequest(string license_version,string license_key)
        {
            try
            {
                using (var client = new WebClient())
                {
                    var values = new NameValueCollection();
                    if (license_version == "1000")
                    {
                        license_version = "InstanceKiller1000";
                    }
                    if (license_version == "3000")
                    {
                        license_version = "InstanceKiller3000";
                    }
                    if (license_version == "6000")
                    {
                        license_version = "InstanceKiller6000";
                    }
                    values["license_version"] = license_version;
                    values["license_key"] = license_key;

                    var response = client.UploadValues(GlobalVar.licenseUrl, values);
                    var responseString = Encoding.Default.GetString(response);
                    return int.Parse(responseString);
                }
            }
            catch
            {
                return -1;
            }
        }
    }
}
