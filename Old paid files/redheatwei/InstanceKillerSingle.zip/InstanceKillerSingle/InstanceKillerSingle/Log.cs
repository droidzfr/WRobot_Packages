﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using robotManager.Helpful;
using InstanceKillerSingle;

namespace InstanceKillerSingle
{
    class Log
    {
        public static void Write(Language Format, params object[] args)
        {
            if (System.Threading.Thread.CurrentThread.CurrentCulture.Name == "zh-CN")
            {
                Logging.Write(string.Format(Local.prefix + Format.zhCN, args));
            }
            else
            {
                Logging.Write(string.Format(Local.prefix + Format.enUS, args));
            }
        }
        public static void WriteError(Language Format, params object[] args)
        {
            if (System.Threading.Thread.CurrentThread.CurrentCulture.Name == "zh-CN")
            {
                Logging.WriteError(string.Format(Local.prefix + Format.zhCN, args));
            }
            else
            {
                Logging.WriteError(string.Format(Local.prefix + Format.enUS, args));
            }
        }
    }
}
