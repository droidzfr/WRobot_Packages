﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstanceKillerSingle
{
    public struct Language
    {
        public string zhCN;
        public string enUS;
    }
    class Local
    {
        public static readonly string prefix= "[InstanceKillerSingle]";
        public static readonly Language contact = new Language
        {
            zhCN = "作者QQ:314389688. Discord:RedheatW#7207. Email:redheatwei@gmail.com",
            enUS = "Author QQ:314389688. Discord:RedheatW#7207. Email:redheatwei@gmail.com",
        };
        public static readonly Language pulseError = new Language
        {
            zhCN = "CustomProfile > Pulse(): {0}",
            enUS = "CustomProfile > Pulse(): {0}",
        };
        public static readonly Language disposeError = new Language
        {
            zhCN = "CustomProfile > Dispose(): {0}",
            enUS = "CustomProfile > Dispose(): {0}",
        };
        public static readonly Language gotoRetrieveCorpse = new Language
        {
            zhCN = "正在前往复活",
            enUS = "Going to retrieve corpse",
        };
        public static readonly Language waitHourEnd = new Language
        {
            zhCN = "等待爆本时间结束",
            enUS = "Waiting one hour time end",
        };
        public static readonly Language enterDungeon = new Language
        {
            zhCN = "进入副本",
            enUS = "Enter Dungeon",
        };
        public static readonly Language currentDungeonRun = new Language
        {
            zhCN = "当前副本次数:{0}",
            enUS = "Current dungeon run:{0}",
        };
        public static readonly Language outDungeon = new Language
        {
            zhCN = "出副本",
            enUS = "Leave Dungeon",
        };
        public static readonly Language openTheDoor = new Language
        {
            zhCN = "开门",
            enUS = "Open The Door",
        };
        public static readonly Language waitLoading = new Language
        {
            zhCN = "等待读条",
            enUS = "Waiting Loading",
        };
        public static readonly Language gotoPoint = new Language
        {
            zhCN = "前往副本节点:{0}",
            enUS = "Go to dungeon point:{0}",
        };
    }

}
