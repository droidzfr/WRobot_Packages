﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using System.Threading;
using System.Reflection;
using System.Resources;
using robotManager.Helpful;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using XmlSerializer = System.Xml.Serialization.XmlSerializer;

namespace InstanceKillerSingle
{
    public partial class InstanceKillerSettingsForm : Form
    {

        private void ChangeLanguage(string lang)
        {
            foreach (Control c in this.Controls)
            {
                ComponentResourceManager resources = new ComponentResourceManager(typeof(InstanceKillerSettingsForm));
                resources.ApplyResources(c, c.Name, new CultureInfo(lang));

            }
        }
        public InstanceKillerSettingsForm()
        {
            //System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.GetCultureInfo("zh");
            InitializeComponent();
        }

        private void InstanceKillerSettingsForm_Load(object sender, EventArgs e)
        {
            if (System.IO.File.Exists(GlobalVar.configFilePath)){
                try
                {
                    SettingsFormVar settingsFormVar;
                    XmlSerializer xs = new XmlSerializer(typeof(SettingsFormVar));
                    using (FileStream fs = new FileStream(GlobalVar.configFilePath, FileMode.Open))
                    {
                        settingsFormVar = xs.Deserialize(fs) as SettingsFormVar;
                    }
                    if (settingsFormVar != null)
                    {
                        this.ChoseDungeonComboBox.SelectedItem = settingsFormVar.choseDungeon;
                        this.LicenseVersionComboBox.SelectedItem = settingsFormVar.licenseVersion;
                        this.LicenseKeyTextBox.Text = settingsFormVar.licenseKey;
                    }
                }catch(Exception ex)
                {
                    Logging.Write(ex.ToString());
                }
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void ChoseDungeonLabel_Click(object sender, EventArgs e)
        {

        }

        private void ChoseDungeonComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ContactMeLinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void ContactMeQQButton_Click(object sender, EventArgs e)
        {

            //System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.GetCultureInfo("zh");

            System.Diagnostics.Process.Start("tencent://message/?uin=314389688&Menu=yes");
        }

        private void ContactMeDiscordButton_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://discord.gg/MxYH4tS");
        }

        private void SaveSettingsButton_Click(object sender, EventArgs e)
        {
            try
            {
                SettingsFormVar settingsFormVar = new SettingsFormVar();
                try
                {
                    settingsFormVar.choseDungeon = this.ChoseDungeonComboBox.SelectedItem.ToString();
                    settingsFormVar.licenseVersion = this.LicenseVersionComboBox.SelectedItem.ToString();
                    settingsFormVar.licenseKey = this.LicenseKeyTextBox.Text.ToString();
                }
                catch
                {
                    MessageBox.Show("Please Select Dungeon!", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                XmlSerializer xs = new XmlSerializer(typeof(SettingsFormVar));
                using (FileStream fs = new FileStream(GlobalVar.configFilePath, FileMode.Create))
                {
                    xs.Serialize(fs, settingsFormVar);
                }
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://gumroad.com/redheat");
        }
    }
}
