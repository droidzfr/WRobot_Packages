﻿using System;
using System.Collections.Generic;
using System.Threading;
using robotManager.FiniteStateMachine;
using robotManager.Helpful;
using robotManager.Products;
using wManager;
using wManager.Wow.Class;
using wManager.Wow.Bot.States;
using wManager.Wow.Bot.Tasks;
using wManager.Wow.Helpers;
using wManager.Wow.ObjectManager;
using wManager.Wow.Enums;
using wManager.Plugin;
using InstanceKillerSingle;
using Timer = robotManager.Helpful.Timer;

/*
 * Base class (required for all custom prolie (no edit class name)
 */
public class CustomProfile : Custom_Profile.ICustomProfile
{
    private static readonly Engine Fsm = new Engine();
    public void Pulse()
    {
        if (Utils.ConfigSettingsForm()) {
            try
            {
                // Update spell list
                SpellManager.UpdateSpellBook();

                // Load CC:
                CustomClass.LoadCustomClass();
                PluginsManager.LoadAllPlugins();

                // FSM
                Fsm.States.Clear();

                Fsm.AddState(new Relogger { Priority = 200 });
                Fsm.AddState(new StopBotIf { Priority = 100 });
                Fsm.AddState(new Pause { Priority = 16 });
                Fsm.AddState(new MyMacro { Priority = 13 });
                Fsm.AddState(new IsAttacked { Priority = 11 });
                Fsm.AddState(new Regeneration { Priority = 12 });
                Fsm.AddState(new Farming { Priority = 8 });
                Fsm.AddState(new ToCorpse { Priority = 5 });
                Fsm.AddState(new Idle { Priority = 0 });
                Fsm.AddState(new ToTown { Priority = 6 });
                Fsm.AddState(new Looting { Priority = 10 });
                Fsm.AddState(new OutInstanceAndToTown { Priority = 4 });
                Fsm.AddState(new EnterInstance { Priority = 5 });
                Fsm.AddState(new InstanceKillerSingleRotation { Priority = 3 });
                Fsm.States.Sort();
                Fsm.StartEngine(10);
                StopBotIf.LaunchNewThread();
                NpcDB.ListNpc.RemoveAll(n => n.CurrentProfileNpc);
                NpcDB.AddNpc(GlobalVar.InstanceKillerSingleSettings.repairNpc, false, true);
                NpcDB.AddNpc(GlobalVar.InstanceKillerSingleSettings.mailNpc, false, true);
                NpcDB.AddNpc(GlobalVar.InstanceKillerSingleSettings.vendorNpc, false, true);
                NpcDB.AcceptOnlyProfileNpc = true;
                foreach (int i in GlobalVar.InstanceKillerSingleSettings.blackListNpc)
                {
                    wManagerSetting.AddBlackListNpcEntry(i, true);
                }
                wManagerSetting.CurrentSetting.CloseIfPlayerTeleported = false;
                Log.Write(Local.contact);
            }
            catch (Exception e)
            {
                try
                {
                    Dispose();
                }
                catch
                {
                }
                Log.WriteError(Local.pulseError, e);
            }
        }
        else
        {
            Products.ProductStop();
        }
       
    }
    public void Dispose()
    {
        try
        {
            CustomClass.DisposeCustomClass();
            Fsm.StopEngine();
            Fight.StopFight();
            MovementManager.StopMove();
        }
        catch (Exception e)
        {
            Log.WriteError(Local.disposeError, e);
        }
    }
}

class ToCorpse : State
{

    public override string DisplayName
    {
        get { return "Corpse State"; }
    }

    public override int Priority
    {
        get { return _priority; }
        set { _priority = value; }
    }

    private int _priority;


    public override bool NeedToRun
    {
        get
        {
            if (ObjectManager.Me.IsAlive)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }

    public override List<State> NextStates
    {
        get { return new List<State>(); }
    }

    public override List<State> BeforeStates
    {
        get { return new List<State>(); }
    }
    public override void Run()
    {
        Log.Write(Local.gotoRetrieveCorpse);
        Interact.Repop();
        Thread.Sleep(400);
        if (Vector3.Distance2D(ObjectManager.Me.PositionCorpse, GlobalVar.InstanceKillerSingleSettings.InstancePositionCorpse) < 0.5f)
        {
            for (int i = 0; i < GlobalVar.InstanceKillerSingleSettings.EnterInstancePoint.Count; i++)
            {
                GoToTask.ToPosition(GlobalVar.InstanceKillerSingleSettings.EnterInstancePoint[i].Postion, 1f);
            }
            Lua.LuaDoString("ToggleAutoRun()");//自己往前跑
            GlobalVar.CurrentInstancePoint = 0;
        }
        else
        {
            GoToTask.ToPosition(ObjectManager.Me.PositionCorpse, 1f);
            Lua.LuaDoString("RetrieveCorpse()");
        }
    }

}

class EnterInstance : State
{

    public override string DisplayName
    {
        get { return "Enter Instance State"; }
    }

    public override int Priority
    {
        get { return _priority; }
        set { _priority = value; }
    }

    private int _priority;


    public override bool NeedToRun
    {
        get
        {
            if (ObjectManager.Me.IsAlive && Usefuls.ContinentId!=GlobalVar.InstanceKillerSingleSettings.CurrentScriptContinentId && Bag.GetContainerNumFreeSlots>wManagerSetting.CurrentSetting.MinFreeBagSlotsToGoToTown)
            {
                if(GlobalVar.InstanceResetTimeList.Count < 5)
                {
                    if (GlobalVar.InstanceResetTimeList[0] == 0)
                    {
                        GlobalVar.InstanceResetTimeList.RemoveAt(0); //移除默认值0
                    }
                    return true;
                }
                if(Utils.GetTimeStamp() - GlobalVar.InstanceResetTimeList[0] > 3600)
                {
                    GlobalVar.InstanceResetTimeList.RemoveAt(0);
                    return true;
                }
                else
                {
                    Log.Write(Local.waitHourEnd);
                }
            }
            return false;
        }
    }

    public override List<State> NextStates
    {
        get { return new List<State>(); }
    }

    public override List<State> BeforeStates
    {
        get { return new List<State>(); }
    }
    public override void Run()
    {
        Log.Write(Local.enterDungeon);
        Lua.LuaDoString("ResetInstances()");
        GlobalVar.CurrentInstancePoint = 0;
        Thread.Sleep(1000);
        for (int i = 0; i < GlobalVar.InstanceKillerSingleSettings.EnterInstancePoint.Count; i++)
        {
            GoToTask.ToPosition(GlobalVar.InstanceKillerSingleSettings.EnterInstancePoint[i].Postion);
            if (GlobalVar.InstanceKillerSingleSettings.EnterInstancePoint[i].Intecract)
            {
                Utils.OpenTheDoor();
            }
        }
        Lua.LuaDoString("ToggleAutoRun()");
        GlobalVar.InstanceResetTimeList.Add(Utils.GetTimeStamp());
        Log.Write(Local.currentDungeonRun, GlobalVar.InstanceResetTimeList.Count);
        Thread.Sleep(3000);
    }

}

class OutInstanceAndToTown : State
{

    public override string DisplayName
    {
        get { return "Out Instance State"; }
    }

    public override int Priority
    {
        get { return _priority; }
        set { _priority = value; }
    }

    private int _priority;


    public override bool NeedToRun
    {
        get
        {
            if (ObjectManager.Me.IsAlive&& Bag.GetContainerNumFreeSlots <= wManagerSetting.CurrentSetting.MinFreeBagSlotsToGoToTown || GlobalVar.CurrentInstancePoint >= GlobalVar.InstanceKillerSingleSettings.EndInstancePoint.Count-1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    public override List<State> NextStates
    {
        get { return new List<State>(); }
    }

    public override List<State> BeforeStates
    {
        get { return new List<State>(); }
    }
    public override void Run()
    {
        /*        if (Bag.GetContainerItemCooldown(6948) <= 0)
                {
                    ItemsManager.UseItem(6948);
                    Thread.Sleep(10000);
                }
                else
                {*/
        if (Usefuls.ContinentId == GlobalVar.InstanceKillerSingleSettings.CurrentScriptContinentId)
        {
            Log.Write(Local.outDungeon);
            for (int i = 0; i < GlobalVar.InstanceKillerSingleSettings.OutInstancePoint.Count; i++)
            {
                GoToTask.ToPosition(GlobalVar.InstanceKillerSingleSettings.OutInstancePoint[i].Postion, 0.1f);
                if (GlobalVar.InstanceKillerSingleSettings.OutInstancePoint[i].Intecract)
                {
                    Log.Write(Local.openTheDoor);
                    Utils.OpenTheDoor();
                }
                while (Usefuls.IsLoadingOrConnecting)
                {
                    Log.Write(Local.waitLoading);
                    Thread.Sleep(10000);
                }
                Thread.Sleep(1000);
            }
        }
        Thread.Sleep(10000);
    }

}


class InstanceKillerSingleRotation : State
{

    public override string DisplayName
    {
        get { return "Run to town State"; }
    }

    public override int Priority
    {
        get { return _priority; }
        set { _priority = value; }
    }

    private int _priority;

    public override bool NeedToRun
    {
        get
        {
            /*            if (Usefuls.ContinentId != GlobalVar.InstanceKillerSingleSettings.CurrentScriptContinentId)
                        {
                            GoToTask.ToPosition(GlobalVar.InstanceKillerSingleSettings.EnterInstancePoint, 1);
                            Thread.Sleep(1000);
                        }
                        else
                        {*/
            if (ObjectManager.Me.IsAlive && Bag.GetContainerNumFreeSlots > wManagerSetting.CurrentSetting.MinFreeBagSlotsToGoToTown && ObjectManager.Me.HealthPercent > wManagerSetting.CurrentSetting.FoodPercent && ObjectManager.Me.ManaPercentage > wManagerSetting.CurrentSetting.DrinkPercent && Usefuls.ContinentId == GlobalVar.InstanceKillerSingleSettings.CurrentScriptContinentId && !ObjectManager.Me.InCombat)
            {
                return true;
            }
            //}
            return false;
        }
    }

    public override List<State> NextStates
    {
        get { return new List<State>(); }
    }

    public override List<State> BeforeStates
    {
        get { return new List<State>(); }
    }
    public override void Run()
    {
        if (GlobalVar.CurrentInstancePoint< GlobalVar.InstanceKillerSingleSettings.EndInstancePoint.Count-1)
        {
            Log.Write(Local.gotoPoint, GlobalVar.InstanceKillerSingleSettings.EndInstancePoint[GlobalVar.CurrentInstancePoint].Postion.ToString());
            //if (GoToTask.ToPosition(GlobalVar.InstanceKillerSingleSettings.EndInstancePoint[GlobalVar.CurrentInstancePoint].Postion))
            if (GoToTask.ToPosition(GlobalVar.InstanceKillerSingleSettings.EndInstancePoint[GlobalVar.CurrentInstancePoint].Postion,1))
                {
                if (GlobalVar.InstanceKillerSingleSettings.EndInstancePoint[GlobalVar.CurrentInstancePoint].Intecract)
                {
                    Utils.OpenTheDoor();
                }
                Fight.StartFight();
                var lootable = ObjectManager.GetWoWUnitLootable();
                if (lootable.Count > 0)
                {
                    LootingTask.Pulse(lootable);
                }
                if (!ObjectManager.Me.InCombat)
                {
                    GlobalVar.CurrentInstancePoint += 1;
                }
            }
        }
    }
}

