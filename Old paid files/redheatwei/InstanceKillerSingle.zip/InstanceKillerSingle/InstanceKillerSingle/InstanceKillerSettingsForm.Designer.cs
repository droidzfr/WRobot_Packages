﻿using System.Windows.Forms;

namespace InstanceKillerSingle
{
    partial class InstanceKillerSettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InstanceKillerSettingsForm));
            this.ChoseDungeonLabel = new System.Windows.Forms.Label();
            this.ChoseDungeonComboBox = new System.Windows.Forms.ComboBox();
            this.ContactMeLabel = new System.Windows.Forms.Label();
            this.ContactMeQQButton = new System.Windows.Forms.Button();
            this.ContactMeDiscordButton = new System.Windows.Forms.Button();
            this.SaveSettingsButton = new System.Windows.Forms.Button();
            this.LicenseVersionComboBox = new System.Windows.Forms.ComboBox();
            this.LicenseVersionLable = new System.Windows.Forms.Label();
            this.LicenseKeyLabel = new System.Windows.Forms.Label();
            this.LicenseKeyTextBox = new System.Windows.Forms.TextBox();
            this.BuyLicenseLinkLabel = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // ChoseDungeonLabel
            // 
            this.ChoseDungeonLabel.AutoSize = true;
            this.ChoseDungeonLabel.Location = new System.Drawing.Point(19, 34);
            this.ChoseDungeonLabel.Name = "ChoseDungeonLabel";
            this.ChoseDungeonLabel.Size = new System.Drawing.Size(89, 12);
            this.ChoseDungeonLabel.TabIndex = 0;
            this.ChoseDungeonLabel.Text = "Chose Dungeon:";
            this.ChoseDungeonLabel.Click += new System.EventHandler(this.ChoseDungeonLabel_Click);
            // 
            // ChoseDungeonComboBox
            // 
            this.ChoseDungeonComboBox.FormattingEnabled = true;
            this.ChoseDungeonComboBox.Items.AddRange(new object[] {
            "Scarlet Monastery - Church",
            "The Stockade - Alliance",
            "Ragefire Chasm - Horde",
            "The Deadmines - Alliance",
            "Shadowfang Keep - Horde",
            "Zul\'Farrak",
            "Scholomance",
            "Stratholme",
            "Blackrock Depths"});
            this.ChoseDungeonComboBox.Location = new System.Drawing.Point(111, 30);
            this.ChoseDungeonComboBox.Name = "ChoseDungeonComboBox";
            this.ChoseDungeonComboBox.Size = new System.Drawing.Size(335, 20);
            this.ChoseDungeonComboBox.TabIndex = 1;
            this.ChoseDungeonComboBox.SelectedIndexChanged += new System.EventHandler(this.ChoseDungeonComboBox_SelectedIndexChanged);
            // 
            // ContactMeLabel
            // 
            this.ContactMeLabel.AutoSize = true;
            this.ContactMeLabel.Location = new System.Drawing.Point(19, 117);
            this.ContactMeLabel.Name = "ContactMeLabel";
            this.ContactMeLabel.Size = new System.Drawing.Size(71, 12);
            this.ContactMeLabel.TabIndex = 2;
            this.ContactMeLabel.Text = "Contact Me:";
            // 
            // ContactMeQQButton
            // 
            this.ContactMeQQButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ContactMeQQButton.BackgroundImage")));
            this.ContactMeQQButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.ContactMeQQButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ContactMeQQButton.Location = new System.Drawing.Point(96, 114);
            this.ContactMeQQButton.Name = "ContactMeQQButton";
            this.ContactMeQQButton.Size = new System.Drawing.Size(18, 18);
            this.ContactMeQQButton.TabIndex = 3;
            this.ContactMeQQButton.UseVisualStyleBackColor = true;
            this.ContactMeQQButton.Click += new System.EventHandler(this.ContactMeQQButton_Click);
            // 
            // ContactMeDiscordButton
            // 
            this.ContactMeDiscordButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ContactMeDiscordButton.BackgroundImage")));
            this.ContactMeDiscordButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ContactMeDiscordButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.ContactMeDiscordButton.Location = new System.Drawing.Point(120, 114);
            this.ContactMeDiscordButton.Name = "ContactMeDiscordButton";
            this.ContactMeDiscordButton.Size = new System.Drawing.Size(18, 18);
            this.ContactMeDiscordButton.TabIndex = 4;
            this.ContactMeDiscordButton.UseVisualStyleBackColor = true;
            this.ContactMeDiscordButton.Click += new System.EventHandler(this.ContactMeDiscordButton_Click);
            // 
            // SaveSettingsButton
            // 
            this.SaveSettingsButton.Location = new System.Drawing.Point(363, 108);
            this.SaveSettingsButton.Name = "SaveSettingsButton";
            this.SaveSettingsButton.Size = new System.Drawing.Size(83, 30);
            this.SaveSettingsButton.TabIndex = 5;
            this.SaveSettingsButton.Text = "Save";
            this.SaveSettingsButton.UseVisualStyleBackColor = true;
            this.SaveSettingsButton.Click += new System.EventHandler(this.SaveSettingsButton_Click);
            // 
            // LicenseVersionComboBox
            // 
            this.LicenseVersionComboBox.FormattingEnabled = true;
            this.LicenseVersionComboBox.Items.AddRange(new object[] {
            "1000",
            "3000",
            "6000"});
            this.LicenseVersionComboBox.Location = new System.Drawing.Point(111, 66);
            this.LicenseVersionComboBox.Name = "LicenseVersionComboBox";
            this.LicenseVersionComboBox.Size = new System.Drawing.Size(85, 20);
            this.LicenseVersionComboBox.TabIndex = 7;
            // 
            // LicenseVersionLable
            // 
            this.LicenseVersionLable.AutoSize = true;
            this.LicenseVersionLable.Location = new System.Drawing.Point(7, 69);
            this.LicenseVersionLable.Name = "LicenseVersionLable";
            this.LicenseVersionLable.Size = new System.Drawing.Size(101, 12);
            this.LicenseVersionLable.TabIndex = 6;
            this.LicenseVersionLable.Text = "License Version:";
            this.LicenseVersionLable.Click += new System.EventHandler(this.label1_Click);
            // 
            // LicenseKeyLabel
            // 
            this.LicenseKeyLabel.AutoSize = true;
            this.LicenseKeyLabel.Location = new System.Drawing.Point(202, 71);
            this.LicenseKeyLabel.Name = "LicenseKeyLabel";
            this.LicenseKeyLabel.Size = new System.Drawing.Size(77, 12);
            this.LicenseKeyLabel.TabIndex = 8;
            this.LicenseKeyLabel.Text = "License Key:";
            this.LicenseKeyLabel.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // LicenseKeyTextBox
            // 
            this.LicenseKeyTextBox.Location = new System.Drawing.Point(291, 66);
            this.LicenseKeyTextBox.Name = "LicenseKeyTextBox";
            this.LicenseKeyTextBox.Size = new System.Drawing.Size(155, 21);
            this.LicenseKeyTextBox.TabIndex = 9;
            // 
            // BuyLicenseLinkLabel
            // 
            this.BuyLicenseLinkLabel.AutoSize = true;
            this.BuyLicenseLinkLabel.Location = new System.Drawing.Point(277, 119);
            this.BuyLicenseLinkLabel.Name = "BuyLicenseLinkLabel";
            this.BuyLicenseLinkLabel.Size = new System.Drawing.Size(71, 12);
            this.BuyLicenseLinkLabel.TabIndex = 11;
            this.BuyLicenseLinkLabel.TabStop = true;
            this.BuyLicenseLinkLabel.Text = "Buy License";
            this.BuyLicenseLinkLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked_1);
            // 
            // InstanceKillerSettingsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(458, 144);
            this.Controls.Add(this.BuyLicenseLinkLabel);
            this.Controls.Add(this.LicenseKeyTextBox);
            this.Controls.Add(this.LicenseKeyLabel);
            this.Controls.Add(this.LicenseVersionComboBox);
            this.Controls.Add(this.LicenseVersionLable);
            this.Controls.Add(this.SaveSettingsButton);
            this.Controls.Add(this.ContactMeDiscordButton);
            this.Controls.Add(this.ContactMeQQButton);
            this.Controls.Add(this.ContactMeLabel);
            this.Controls.Add(this.ChoseDungeonComboBox);
            this.Controls.Add(this.ChoseDungeonLabel);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Name = "InstanceKillerSettingsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "InstanceKillerSettings";
            this.Load += new System.EventHandler(this.InstanceKillerSettingsForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ChoseDungeonLabel;
        private System.Windows.Forms.ComboBox ChoseDungeonComboBox;
        private System.Windows.Forms.Label ContactMeLabel;
        private System.Windows.Forms.Button ContactMeQQButton;
        private System.Windows.Forms.Button ContactMeDiscordButton;
        private System.Windows.Forms.Button SaveSettingsButton;
        private ComboBox LicenseVersionComboBox;
        private Label LicenseVersionLable;
        private Label LicenseKeyLabel;
        private TextBox LicenseKeyTextBox;
        private LinkLabel BuyLicenseLinkLabel;
    }
}